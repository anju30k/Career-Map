package com.example.career_map

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
